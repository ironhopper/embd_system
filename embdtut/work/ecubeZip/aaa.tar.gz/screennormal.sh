xrandr -o normal
xinput set-prop 'WaveShare WaveShare Touchscreen' 'Coordinate Transformation Matrix' 1 0 0 0 1 0 0 0 1