xinput set-prop 'WaveShare WaveShare Touchscreen' 'Coordinate Transformation Matrix' 0 -1 1 1 0 0 0 0 1
